//
//  common.cpp
//  Arkanoid
//
//  Created by ChrisLam on 22/03/2021.
//

#include "common.hpp"

SDL_Renderer* g_renderer = nullptr;
